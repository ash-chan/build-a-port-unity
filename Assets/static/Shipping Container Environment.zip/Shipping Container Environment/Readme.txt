Author: MutantGopher
mutantgopher.com

This shipping container pack provides you with the assets to create a complete cargo yard environment.

Included Prefabs:
- Shipping container 1
- Shipping container 1 Open
- Shipping container 2
- Shipping container 2 Open
- Shipping container 3
- Shipping container 3 Open
- Shipping container 4
- Shipping container 4 Open
- Warehouse 1
- Shelf 1
- Light 1
- Light 2
- Beam vertical
- Beam horizontal
- Beam support
- Ladder 1
- Ladder 2
- Ramp metal 1
- Ramp support 1
- Panel metal 1
- Panel metal 2
- Panel metal 3
- Panel metal 4
- Panel walkway 1
- Panel walkway 2
- Rail 1
- Rail 2
- Pallet 1
- Pallet stack 1
- Pallet stack 2
- Pallet stack 3
- Pallet full 1
- Pallet full 2
- Cardboard box 1
- Cardboard box 2
- Cardboard box 3
- Concrete slab 1
- Decal 1
- Decal 2
- Decal 3
- Decal 4

